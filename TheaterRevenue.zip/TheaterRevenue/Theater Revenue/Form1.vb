﻿Public Class Form1
    'JEFFREY HAGAN
    'VB FOR BUSINESS
    'Theater Revenue Calculator
    '2/13/18

    Private Const COMMISSION_RATE As Double = 0.2
    Dim intAdultppt, intChildppt, intAdultTicketSold, intChildTicketSold, intTotalGross, intHold, intHold2 As Integer



    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click


        Try
            'this takes input from textbox 
            'converts it to integer And holds information in 
            'intAdult/ intAdultTicketsSold variable
            intAdultppt = CInt(txtAdultPptInput.Text)
            intAdultTicketSold = CInt(txtNumTicketsSoldAdult.Text)
            'same as code above
            intChildppt = CInt(txtChildPptInput.Text)
            intChildTicketSold = CInt(txtNumTicketsSoldChild.Text)
        Catch
            MsgBox("Please enter numerical numbers", MsgBoxStyle.OkOnly,)
        End Try


        'this will add the results above and convert them into string
        'then will be displayed in gross adult ticket sales and child ticket sales
        lblOutputAdult.Text = CStr(intAdultppt * intAdultTicketSold)
        lblOutputChild.Text = CStr(intChildppt * intChildTicketSold)

        'this will store result in intHold
        intHold = CInt(lblOutputAdult.Text) + CInt(lblOutputChild.Text)
        'results in intHold will be output put into total gross in currency format
        lblOutputTotalGross.Text = intHold.ToString("c")

        'converts results in total gross adult/child into integer and mulitplies it by the commission rate
        'and out puts results in net sales for adult/child and total
        lblOutputAdultaNet.Text = CInt(lblOutputAdult.Text) * COMMISSION_RATE
        lblOutputChildNet.Text = CInt(lblOutputChild.Text) * COMMISSION_RATE
        'results will be placed in intHold variable
        intHold2 = CInt(lblOutputAdultaNet.Text) + CInt(lblOutputChildNet.Text)
        'intHold2 converted into currenct and display as currency in total net output
        lblOutputTotalNet.Text = intHold2.ToString("c")


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'this will clear any input in text box
        txtAdultPptInput.Text = ""
        txtChildPptInput.Text = ""
        txtNumTicketsSoldAdult.Text = ""
        txtNumTicketsSoldChild.Text = ""

        'this will clear code in labels
        lblOutputAdult.Text = ""
        lblOutputChild.Text = ""
        lblOutputAdultaNet.Text = ""
        lblOutputChildNet.Text = ""
        lblOutputTotalGross.Text = ""
        lblOutputTotalNet.Text = ""

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
