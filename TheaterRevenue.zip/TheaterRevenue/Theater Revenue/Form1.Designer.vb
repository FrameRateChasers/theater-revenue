﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblOutputAdult = New System.Windows.Forms.Label()
        Me.lblOutputChild = New System.Windows.Forms.Label()
        Me.lblOutputTotalGross = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtAdultPptInput = New System.Windows.Forms.TextBox()
        Me.txtNumTicketsSoldAdult = New System.Windows.Forms.TextBox()
        Me.txtChildPptInput = New System.Windows.Forms.TextBox()
        Me.txtNumTicketsSoldChild = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblOutputTotalNet = New System.Windows.Forms.Label()
        Me.lblOutputChildNet = New System.Windows.Forms.Label()
        Me.lblOutputAdultaNet = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(154, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Adult Ticket Sales"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Price per ticket"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(46, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Tickets sold"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(25, 206)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(186, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Gross Ticket Revenue"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(24, 258)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(147, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Adult ticket sales"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(25, 307)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Child ticket sales"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(24, 346)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(183, 40)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Total Gross Revenue " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for ticket sales"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(371, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(178, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Children Ticket Sales"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(371, 81)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(129, 20)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Price per ticket"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(396, 122)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(104, 20)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Tickets sold"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(371, 206)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(140, 20)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Net Ticket Sales"
        '
        'lblOutputAdult
        '
        Me.lblOutputAdult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputAdult.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputAdult.Location = New System.Drawing.Point(213, 245)
        Me.lblOutputAdult.Name = "lblOutputAdult"
        Me.lblOutputAdult.Size = New System.Drawing.Size(113, 33)
        Me.lblOutputAdult.TabIndex = 11
        '
        'lblOutputChild
        '
        Me.lblOutputChild.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputChild.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputChild.Location = New System.Drawing.Point(213, 294)
        Me.lblOutputChild.Name = "lblOutputChild"
        Me.lblOutputChild.Size = New System.Drawing.Size(113, 33)
        Me.lblOutputChild.TabIndex = 12
        '
        'lblOutputTotalGross
        '
        Me.lblOutputTotalGross.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputTotalGross.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputTotalGross.Location = New System.Drawing.Point(213, 353)
        Me.lblOutputTotalGross.Name = "lblOutputTotalGross"
        Me.lblOutputTotalGross.Size = New System.Drawing.Size(113, 33)
        Me.lblOutputTotalGross.TabIndex = 13
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(28, 427)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(187, 58)
        Me.btnCalc.TabIndex = 14
        Me.btnCalc.Text = "Calculate Ticket Revenue"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(262, 427)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(187, 58)
        Me.btnClear.TabIndex = 15
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(493, 427)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(187, 58)
        Me.btnExit.TabIndex = 16
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtAdultPptInput
        '
        Me.txtAdultPptInput.Location = New System.Drawing.Point(170, 81)
        Me.txtAdultPptInput.Name = "txtAdultPptInput"
        Me.txtAdultPptInput.Size = New System.Drawing.Size(100, 20)
        Me.txtAdultPptInput.TabIndex = 17
        '
        'txtNumTicketsSoldAdult
        '
        Me.txtNumTicketsSoldAdult.Location = New System.Drawing.Point(170, 122)
        Me.txtNumTicketsSoldAdult.Name = "txtNumTicketsSoldAdult"
        Me.txtNumTicketsSoldAdult.Size = New System.Drawing.Size(100, 20)
        Me.txtNumTicketsSoldAdult.TabIndex = 18
        '
        'txtChildPptInput
        '
        Me.txtChildPptInput.Location = New System.Drawing.Point(520, 81)
        Me.txtChildPptInput.Name = "txtChildPptInput"
        Me.txtChildPptInput.Size = New System.Drawing.Size(100, 20)
        Me.txtChildPptInput.TabIndex = 19
        '
        'txtNumTicketsSoldChild
        '
        Me.txtNumTicketsSoldChild.Location = New System.Drawing.Point(520, 122)
        Me.txtNumTicketsSoldChild.Name = "txtNumTicketsSoldChild"
        Me.txtNumTicketsSoldChild.Size = New System.Drawing.Size(100, 20)
        Me.txtNumTicketsSoldChild.TabIndex = 20
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(378, 346)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(163, 40)
        Me.Label15.TabIndex = 23
        Me.Label15.Text = "Total Net Revenue " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for ticket sales"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(387, 307)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(145, 20)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Child ticket sales"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(378, 258)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(154, 20)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Adult Ticket Sales"
        '
        'lblOutputTotalNet
        '
        Me.lblOutputTotalNet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputTotalNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputTotalNet.Location = New System.Drawing.Point(567, 353)
        Me.lblOutputTotalNet.Name = "lblOutputTotalNet"
        Me.lblOutputTotalNet.Size = New System.Drawing.Size(113, 32)
        Me.lblOutputTotalNet.TabIndex = 26
        '
        'lblOutputChildNet
        '
        Me.lblOutputChildNet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputChildNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputChildNet.Location = New System.Drawing.Point(567, 294)
        Me.lblOutputChildNet.Name = "lblOutputChildNet"
        Me.lblOutputChildNet.Size = New System.Drawing.Size(113, 33)
        Me.lblOutputChildNet.TabIndex = 25
        '
        'lblOutputAdultaNet
        '
        Me.lblOutputAdultaNet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputAdultaNet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputAdultaNet.Location = New System.Drawing.Point(567, 245)
        Me.lblOutputAdultaNet.Name = "lblOutputAdultaNet"
        Me.lblOutputAdultaNet.Size = New System.Drawing.Size(113, 33)
        Me.lblOutputAdultaNet.TabIndex = 24
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(12, 197)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(325, 206)
        Me.Button4.TabIndex = 27
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(365, 197)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(325, 206)
        Me.Button5.TabIndex = 28
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(12, 12)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(325, 154)
        Me.Button6.TabIndex = 29
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(365, 12)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(325, 154)
        Me.Button7.TabIndex = 30
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(714, 513)
        Me.Controls.Add(Me.lblOutputTotalNet)
        Me.Controls.Add(Me.lblOutputChildNet)
        Me.Controls.Add(Me.lblOutputAdultaNet)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.txtNumTicketsSoldChild)
        Me.Controls.Add(Me.txtChildPptInput)
        Me.Controls.Add(Me.txtNumTicketsSoldAdult)
        Me.Controls.Add(Me.txtAdultPptInput)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblOutputTotalGross)
        Me.Controls.Add(Me.lblOutputChild)
        Me.Controls.Add(Me.lblOutputAdult)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Name = "Form1"
        Me.Text = "Theater Revenue Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents lblOutputAdult As Label
    Friend WithEvents lblOutputChild As Label
    Friend WithEvents lblOutputTotalGross As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtAdultPptInput As TextBox
    Friend WithEvents txtNumTicketsSoldAdult As TextBox
    Friend WithEvents txtChildPptInput As TextBox
    Friend WithEvents txtNumTicketsSoldChild As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents lblOutputTotalNet As Label
    Friend WithEvents lblOutputChildNet As Label
    Friend WithEvents lblOutputAdultaNet As Label
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
End Class
